Author - Nothing Loud/lionellion/ /u/Ok_Excitement5874

Credits - Heavily inspired/borrowed code from /u/Takia_Gecko

Special Thanks - Google Bard for helping with debugging and revising some code

Use: Just run the "Get-YuzuUpdateHDR.exe" file in this package.

Notes: This code automatically manages, backs-up, and updates your yuzu folders every time you run it. 
You must specify your yuzu folder and then it will always remember the current folder unless you change its name, then you will have to re-specify the folder.
The best thing about this is that it auto-launches the latest yuzu EA from pinEApple and it even renames/converts your files to trigger Auto-HDR in Windows 11!
If your yuzu is fully updated, then it checks that the files and folders are properly arranged and auto-launches Auto-HDR-capable yuzu EA.

WARNING! This only works on Windows, I'm sorry to Linux and MacOS users.

I wrote this myself by learning PowerShell over the weekend with Google Bard, and based it off of Takia_Gecko's code but added the HDR functionality. It may trigger virus software because it is unsigned. I don't have a code-signing certificate, I'm sorry. However, as you can see from the code in the .exe and .ps1, there is nothing harmful to your system!

Enjoy! :)